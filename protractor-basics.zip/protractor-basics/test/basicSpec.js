describe('Basic protractor feature', function(){

    it('should get the title', async function(){
        browser.get('https://example.com');
        var title = browser.getTitle();
        browser.getTitle().then(function (pageTitle){
            expect(pageTitle).toEqual('Example Domain');
        });
    });
});