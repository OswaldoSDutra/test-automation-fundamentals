//const path = require('path');
//const SPECS_PATH = path.resolve(process.cwd(), 'test');

//console.log(SPECS_PATH);

exports.config = {
    directConnect: false,
    framework: 'jasmine',
    capabilities:{
        browserName: 'firefox',
    },
    seleniumAddress: "http://localhost:4444/wd/hub",
    specs: ['test/*.js'],

    onPrepare: async () => {
        browser.ignoreSynchronization = true;
    }
};